RSP BLR v2
- Catalogue uses the latest list supplied in chat.
- Order text preserves model + brand exactly as entered in the catalogue.
- Replace waNumber in index.html with the business WhatsApp number.
- Upload index.html and logo.jpg to GitHub Pages.
